# Importação de um módulo dentro de um pacote
#from Graphics import Bmp
#Bmp.load('teste.bpm')

#from Graphics.Bmp import *
#load('teste1.bmp')

from Graphics import *
Bmp.load('teste2.bpm')
Jpeg.load('teste.jpeg')
Png.save('teste.png')

